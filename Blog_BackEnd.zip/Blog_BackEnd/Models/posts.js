var mongoose = require('mongoose');

const posts = new mongoose.Schema({
    
    postTitle : { type : String,required : true},
    postDescriptions : { type : String,required : true},
    postComments : { type : String,required : true},
    postLikes : { type : Number,required : true,default:0},
    postImgPath : { type :String,required : true},
    user : {
        type : mongoose.Schema.Types.ObjectId,
        ref : 'userRegistrations'
    }
});

module.exports = mongoose.model('Post',posts);