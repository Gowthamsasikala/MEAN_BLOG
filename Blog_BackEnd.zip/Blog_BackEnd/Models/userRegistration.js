var mongoose = require('mongoose');

const userRegistration = new mongoose.Schema({
    firstName : { type : String,required : true},
    lastName : { type : String , required:true},
    password : { type : String , required:true},
    confirmPassword : {type:String,required:true},
    email: { type : String , required:true},
    phoneNumber :{ type : String , required:true},
    gender :{ type : String , required:true},
    country : { type : String , required:true},
    post : [{
        type : mongoose.Schema.Types.ObjectId,
        ref : 'Post'
    }]
});

module.exports = mongoose.model('userRegistrations',userRegistration);