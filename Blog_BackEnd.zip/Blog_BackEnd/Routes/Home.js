var express = require('express');
var home = express.Router();
var posters = require('../Models/posts');


home.get('/all',function(req,res){

    posters.find().populate('user').exec(function(err,data){
           if(err){
               res.json({Error:'Error in getting all the posters..'});
           }else{
               res.json(data);
           }
    });

});

module.exports = home;