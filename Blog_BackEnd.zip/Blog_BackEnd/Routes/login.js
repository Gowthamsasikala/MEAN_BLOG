var express = require('express');
var routes = express.Router();
var userRegister = require('../Models/userRegistration');
var poster = require('../Models/posts');
var multer = require('multer');
var fs = require('fs');



var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'uploads/')
    },
    filename: function (req, file, cb) {
        const extension = file.mimetype.split('/');
      cb(null, file.fieldname + '-' + Date.now()+'.'+extension[1])
    }
  });
  
var upload = multer({ storage : storage }).single('images')
var id ;

routes.get('/profile', function (req, res) {
   
    fs.readdir('uploads/',function(err, items){
        console.log(items);
    });
  });


routes.post('/login',function(req,res){
    console.log("hu");
    var first = req.body.firstName;
    var pass = req.body.password;
    console.log(first+"---"+pass);
    userRegister.find({firstName:first,password:pass},function(err,data){
        if(err){
            res.json({Error:'Error in finding the users info...'});
        }else{
            if(data.length === 0 || data === null ||  data === undefined){
                res.json({Message:'Incorrect Username or Password..'});

            }else{
                console.log(data);
                res.cookie('_id',data[0]['_id']);
                console.log(data[0]['_id']);
                res.json({Success:'User successfully logged In..',data});
            }
        }  

    });

});

routes.post('/Registration',function(req,res){
   var email = req.body.email;
   var firstName = req.body.firstName;
  userRegister.find({email:email,firstName:firstName},function(err,data){
           
      if(data == null || data == undefined || data.length ==0){
          
          const users = new userRegister({
              firstName : req.body.firstName,
              lastName :req.body.lastName,
              password : req.body.password,
              confirmPassword : req.body.confirmPassword,
              email : req.body.email,
              phoneNumber :  req.body.phoneNumber,
              gender : req.body.gender,
              country:req.body.country  
          });
          users.save(function(err){
             if(err){ 
                 res.json({error:'Error in saving Data..'});
            }else{
                 res.json({success:'User has saved to the Database Successfully...'});
             }
          });
      }else{
          res.json({Message:'User Already Exists with this name and emailId...'});
      }
  });   

  });


routes.post('/post',function(req,res){
      var paths ;
       upload(req, res, function (err) {
        if (err) {
           res.error("error");
         }else{
     
         paths = req.file.path.split('\\');
       
         
         console.log(req.body.user);
         const post = new poster({
             postTitle : req.body.postTitle,
             postDescriptions : req.body.postDescriptions,
             postComments : req.body.postComments,
             postLikes : Number(req.body.postLikes),
             postImgPath :paths[1],
             user : req.body.user
         });
       console.log(post);
         post.save(function(err,data){
              if(err){
                  res.json({Error:'Error in saving post '+err});
              }else{
                  res.json(data);
              }
         });
          
        }
       });
     

});


routes.put('/post/likes',function(req,res){
    
    poster.updateOne({_id:req.body.userId},{postLikes:req.body.Likes + 1},(err,data)=>{
            if(err){
                res.json({error:"Error Occured.."});
            }else{
                res.json({Success:"Likes Added to the user.."});
            }
    });
});


routes.post('/getUsersInfo',function(req,res){
        console.log(req.body.userIds);
    poster.find({user:req.body.userIds}).populate('user').exec((err,data)=>{
        if(err){
            res.json({err:"error Occured.."});
        }else{
            res.json(data);
        }     
    });

     
});




module.exports = routes;