module.exports = {
    mongoURI : 'mongodb://gowtham:<password>@nodemongo-shard-00-00-u6gcu.mongodb.net:27017,nodemongo-shard-00-01-u6gcu.mongodb.net:27017,nodemongo-shard-00-02-u6gcu.mongodb.net:27017/test?ssl=true&replicaSet=NodeMongo-shard-0&authSource=admin&retryWrites=true' ,
    secretOrKey : 'SECRET'
};