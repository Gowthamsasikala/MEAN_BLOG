var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var cors = require('cors');
var path = require('path');
var router = require('./Routes/login');
var Home = require('./Routes/Home');
var cookieParser = require('cookie-parser');


//mongoose.connect("mongodb://localhost:27017/blogs");

mongoose.connect("mongodb+srv://gowtham123:gowtham123@mean-almok.mongodb.net/test?retryWrites=true",{
    useNewUrlParser : true,
   
});

// mongoose.connection.on('connected',()=>{
//     console.log('connected to the server 27017');
// });

// mongoose.connection.on('err',()=>{
//     if(err){
//         console.log("can't connected to the server..");
//     }
// });


var app = express();
app.use(cookieParser());
app.use(express.static('uploads/'));
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.all("/*", function(req, res, next){
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With');
  next();
});
app.options('*', cors());

var port = 3200;

app.listen(port,(err)=>{
    if(err){
        console.log(err);
    
    }else{
        console.log("connected to the port "+port);
    }
    });

app.use('/user/Home',Home);
app.use('/user',router);