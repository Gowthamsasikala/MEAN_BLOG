import { HttpHeaders } from '@angular/common/http';
export const httpOptions = {
    headers: new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('Access-Control-Allow-Origin', '*')
      .set('Access-Control-Allow-Methods', 'POST, GET, OPTIONS, DELETE, PUT')
  };

  export const httpForm = {
    headers: new HttpHeaders()
      
      .set('Content-Type','application/x-www-form-urlencoded')
      .set('Access-Control-Allow-Origin', '*')
      .set('Access-Control-Allow-Methods', 'POST, GET, OPTIONS, DELETE, PUT')
    
  }