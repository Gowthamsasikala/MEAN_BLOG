import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { httpOptions } from '../../CrossOrigin/HeaderFunc';
import { httpForm } from './../../CrossOrigin/HeaderFunc';
@Injectable({
  providedIn: 'root'
})
export class AddpostService {

  constructor(private http:HttpClient) { }

  addPostVal(postObj:FormData){
    const url = 'http://localhost:3200/user/post';
    return this.http.post(url,postObj);
  }

  addPostLikes(id:any){
    const url = 'http://localhost:3200/user/post/likes';
    return this.http.put(url,id,httpOptions);
  }

  getUsersInfo(userId:any){
    const url = 'http://localhost:3200/user/getUsersInfo';
    return this.http.post(url,userId,httpOptions);
  }
}
