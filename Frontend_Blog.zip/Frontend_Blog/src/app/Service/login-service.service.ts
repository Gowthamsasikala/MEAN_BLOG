import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { RequestOptions, Headers } from '@angular/http';
import { httpOptions } from '../../CrossOrigin/HeaderFunc';
@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {

  constructor(private http:HttpClient) { }

 loginCrendentials(obj:any){
   console.log(obj);
   const url = "http://localhost:3200/user/login";
   return this.http.post(url,obj,httpOptions);
 }

 userRegister(user:any){
  const url = "http://localhost:3200/user/Registration";
  return this.http.post(url,user,httpOptions);
 }

 getAllPost(){
  
  const url = "http://localhost:3200/user/Home/all";

   return this.http.get(url);
 }
}
