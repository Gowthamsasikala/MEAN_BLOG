import { Injectable } from '@angular/core';
import { Http }  from '@angular/http';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class NavitemsService {

  constructor(private http : HttpClient) { }

  getnavItems(){
    const Url = "http://localhost:4000/navitems.json";

    return this.http.get(Url);
   
  }

}
