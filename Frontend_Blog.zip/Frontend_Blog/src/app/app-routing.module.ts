import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { NavigationComponent } from './navigation/navigation.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {path:'Login',component:LoginComponent},
  {path : '',component : LoginComponent},
  {path:'welcome',component:WelcomeComponent , children:[
    { path:'Home',component:HomeComponent ,outlet:'contentBody'},
    { path : 'Home/myProfile',component:HomeComponent,outlet :'contentBody'}
  ]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
