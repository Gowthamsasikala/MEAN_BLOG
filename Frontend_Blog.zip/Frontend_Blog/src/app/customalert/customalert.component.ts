import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-customalert',
  templateUrl: './customalert.component.html',
  styleUrls: ['./customalert.component.css']
})
export class CustomalertComponent implements OnInit {

@Input()
public name:String;

@Input()
public msg:String;


  constructor() { }

  ngOnInit() {
    
  }

}
