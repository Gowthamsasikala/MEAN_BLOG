import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginServiceService } from '../Service/login-service.service';
import { addPost } from '../../dto/addPost';
import { AddpostService } from './../Service/addpost.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public profileBoolean : Boolean = false;
  public listAllPost : any;
  public UsersPost : any;
  public post:addPost = new addPost();
  public userId:String;
  public fileName :String;
  public formData =new FormData();
  constructor(private router:Router,private loginserv:LoginServiceService,private addpostser:AddpostService) { }

  ngOnInit() {
     this.userId = sessionStorage.getItem('userId');
      console.log(this.userId);
      var urls = this.router.url.split('/');
    if(urls[urls.length-1] === 'myProfile)'){
      const user = { 
        userIds : this.userId
      }
      this.addpostser.getUsersInfo(user).subscribe(data=>{
        console.log(data);
        this.UsersPost = data;

      })
      this.profileBoolean = true;
      
    }else{
      this.profileBoolean = false;
    }
    this.loginserv.getAllPost().subscribe(data =>{
      console.log(data);
      this.listAllPost = data;
    })
  }
  

  public postToDb(){
    const postVal = {
      postTitle : this.post.Title,
      postDescriptions:this.post.Descriptions,
      postComments : this.post.Comments,
      postLikes: 0,
      user : this.userId
    }
    this.userId = sessionStorage.getItem('userId');
    console.log(this.userId);
    this.formData.append('postTitle',String(this.post.Title));
    this.formData.append('postDescriptions',String(this.post.Descriptions));
    this.formData.append('postComments',String(this.post.Comments));
    this.formData.append('postLikes','0');
    this.formData.append('user',sessionStorage.getItem('userId'));

    console.log(this.formData);
    this.addpostser.addPostVal(this.formData).subscribe(data=>{
      console.log(data);
    })
  }

public file(fileInputs){
  // const fileObj = new Object();
  // fileObj['fileValues'] = fileInputs.target.files;
 this.fileName = fileInputs.target.files[0].name;
  // fileObj['fileExtension'] = v.split('.')[1];
  // fileObj['fileName'] = v.split('.')[0];
   this.formData.append('images',fileInputs.target.files[0]); 
  
}
  public likes(data,index){
   console.log(data);
   const userLikes = {
    userId : data['_id'],
    Likes : data['postLikes']
   }
   //var userId = data['_id'];
   this.addpostser.addPostLikes(userLikes).subscribe(data=>{
     console.log(data);
   })
  
  }

  
}
