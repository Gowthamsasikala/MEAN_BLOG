import { Component, OnInit } from '@angular/core';
import { userRegistration } from '../../dto/userRegistration';
import { RouterModule } from '@angular/router';
import {Router} from '@angular/router';
import { LoginServiceService } from '../Service/login-service.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers:[ LoginServiceService ]
})
export class LoginComponent implements OnInit {
public newUsers : Boolean = false;
public userRegister : userRegistration = new userRegistration();
public firstName:String;
public password : String;
public alerts:Boolean = false;
public success:Boolean = false;
public failure : Boolean = false;
public msgs:String;
  constructor(private router:Router,private loginserv:LoginServiceService) { }

  ngOnInit() {
  
  }


 public newUser(){
 this.newUsers = true;
 }

 public Register(){
  // console.log(this.userRegister.userLogin.firstName);
   console.log(this.userRegister.firstName);
   const Registers = {
      firstName : this.userRegister.firstName,
      lastName :this.userRegister.lastName,
      password : this.userRegister.password,
      confirmPassword : this.userRegister.confirmPassword,
      email:this.userRegister.email,
      country:this.userRegister.country,
      phoneNumber :this.userRegister.phoneNumber,
      gender:this.userRegister.gender

   }
  this.loginserv.userRegister(Registers).subscribe(data=>{
   console.log(data);
   this.msgs = data['success'];
   console.log(this.msgs);
   if(data['success'] === 'User has saved to the Database Successfully...'){
     this.success = true;
   }else{
     this.failure = true;
   }
  });

  this.userRegister.firstName = '';
  this.userRegister.lastName = '';
  this.userRegister.password = '';
  this.userRegister.confirmPassword = '';
  this.userRegister.email = '';
  this.userRegister.gender = '';
  this.userRegister.phoneNumber='';
  this.userRegister.country ='';
  this.alerts = true;
 }

 public login(){
   this.newUsers = false;
 }

 signin(){
   let users = {
     firstName : this.userRegister.userLogin.firstName,
     password : this.userRegister.userLogin.password
   };
    this.loginserv.loginCrendentials(users).subscribe(data=>{
      console.log(data);
      sessionStorage.setItem('userId',data['data'][0]['_id']);
      if(data['Success'] === 'User successfully logged In..'){
             this.router.navigateByUrl('welcome/(contentBody:Home)');
      }
    })
 }


}
