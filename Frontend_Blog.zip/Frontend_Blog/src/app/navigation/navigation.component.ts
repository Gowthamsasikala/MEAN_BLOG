import { Component, OnInit } from '@angular/core';
import { NavitemsService } from '../Service/navitems.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css'],
  providers :[NavitemsService]
})
export class NavigationComponent implements OnInit  {
  public navMenu:any;
  constructor(private navService:NavitemsService,private router : Router) { }
 
  
  ngOnInit() {
   
     this.navService.getnavItems().subscribe((data)=>{
       console.log(data);
       this.navMenu = data;
     });

  }


  public routes(url:any){
    console.log(url);
    this.router.navigateByUrl(url);
  }
}
