export class addPost{
    Title:String;
    Descriptions:String;
    Comments:String;
    Likes:Number;
}