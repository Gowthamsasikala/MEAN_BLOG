export class Logins {
    firstName : String;
    password : String;
}