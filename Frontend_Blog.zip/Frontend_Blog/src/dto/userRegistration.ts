import {Logins} from './userLogins';
export class userRegistration {
    userLogin : Logins = new Logins();
    firstName : String;
    lastName : String;
    password : String;
    confirmPassword: String;
    email:String;
    phoneNumber:String;
    gender:String;
    country:String;
}